// Функция удаления строки из списка
function deleteRow(button) {
  const confirmed = window.confirm('Удалить этот элемент?');
  if (!confirmed) return;
  
  const row = button.closest('.list-row');
  if (row && row.parentElement) {
    row.remove();
  }
}
