// Явная функция удаления строки (для кнопки onclick="deleteRow(this)")
function deleteRow(button) {
  const confirmed = window.confirm('Удалить этот элемент?');
  if (!confirmed) return;

  const row = button.closest('.list-row');
  if (row && row.parentElement) {
    row.parentElement.removeChild(row);
  }
}
